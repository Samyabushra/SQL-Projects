--Simple Queries

-- 1
SELECT * FROM Employee;

-- 2
SELECT * FROM Department;

-- 3
SELECT * FROM Job;

-- 4
SELECT * FROM Location;

-- 5
SELECT First_Name, Last_Name, Salary, Comm
FROM Employee;

-- 6
SELECT Employee_ID AS "ID of the Employee",
       Last_Name AS "Name of the Employee",
       Department_ID AS "Dep_id"
FROM Employee;

-- 7
SELECT First_Name,
       Last_Name,
       Salary*12 AS Annual_Salary
FROM Employee;

--WHERE Clause

-- 1
SELECT * FROM Employee
WHERE Last_Name='Smith';

-- 2
SELECT * FROM Employee
WHERE Department_ID=20;

-- 3
SELECT * FROM Employee
WHERE Salary BETWEEN 3000 AND 4500;

-- 4
SELECT * FROM Employee
WHERE Department_ID IN (10,20);

-- 5
SELECT * FROM Employee
WHERE Department_ID NOT IN (10,30);

-- 6
SELECT * FROM Employee
WHERE Last_Name LIKE 'S%';

-- 7
SELECT * FROM Employee
WHERE Last_Name LIKE 'S%H';

-- 8
SELECT * FROM Employee
WHERE Last_Name LIKE 'S___';

-- 9
SELECT * FROM Employee
WHERE Department_ID=10
AND Salary>3500;

-- 10
SELECT * FROM Employee
WHERE Comm IS NULL;

--ORDER BY
-- 1
SELECT Employee_ID, Last_Name
FROM Employee
ORDER BY Employee_ID ASC;

-- 2
SELECT Employee_ID, Last_Name
FROM Employee
ORDER BY Salary DESC;

-- 3
SELECT *
FROM Employee
ORDER BY Last_Name ASC;

-- 4
SELECT *
FROM Employee
ORDER BY Last_Name ASC, Department_ID DESC;

--GROUP BY & HAVING

-- 1
SELECT Department_ID, COUNT(*) AS Total_Employees
FROM Employee
GROUP BY Department_ID;

-- 2
SELECT Department_ID,
MAX(Salary),
MIN(Salary),
AVG(Salary)
FROM Employee
GROUP BY Department_ID;

-- 3
SELECT Job_ID,
MAX(Salary),
MIN(Salary),
AVG(Salary)
FROM Employee
GROUP BY Job_ID;

-- 4
SELECT MONTH(Hire_Date) AS Month,
COUNT(*)
FROM Employee
GROUP BY MONTH(Hire_Date)
ORDER BY Month;

-- 5
SELECT YEAR(Hire_Date) AS Year,
MONTH(Hire_Date) AS Month,
COUNT(*)
FROM Employee
GROUP BY YEAR(Hire_Date),MONTH(Hire_Date)
ORDER BY Year,Month;

-- 6
SELECT Department_ID
FROM Employee
GROUP BY Department_ID
HAVING COUNT(*)>=4;

-- 7
SELECT COUNT(*)
FROM Employee
WHERE MONTH(Hire_Date)=1;

-- 8
SELECT COUNT(*)
FROM Employee
WHERE MONTH(Hire_Date) IN (1,9);

-- 9
SELECT COUNT(*)
FROM Employee
WHERE YEAR(Hire_Date)=1985;

-- 10
SELECT MONTH(Hire_Date),COUNT(*)
FROM Employee
WHERE YEAR(Hire_Date)=1985
GROUP BY MONTH(Hire_Date);

-- 11
SELECT COUNT(*)
FROM Employee
WHERE YEAR(Hire_Date)=1985
AND MONTH(Hire_Date)=3;

-- 12
SELECT Department_ID
FROM Employee
WHERE YEAR(Hire_Date)=1985
AND MONTH(Hire_Date)=4
GROUP BY Department_ID
HAVING COUNT(*)>=3;

--JOINS

-- 1
SELECT e.First_Name,e.Last_Name,d.Name
FROM Employee e
JOIN Department d
ON e.Department_ID=d.Department_ID;

-- 2
SELECT e.First_Name,e.Last_Name,j.Designation
FROM Employee e
JOIN Job j
ON e.Job_ID=j.Job_ID;

-- 3
SELECT e.First_Name,
d.Name,
l.City
FROM Employee e
JOIN Department d
ON e.Department_ID=d.Department_ID
JOIN Location l
ON d.Location_ID=l.Location_ID;

-- 4
SELECT d.Name,
COUNT(*)
FROM Employee e
JOIN Department d
ON e.Department_ID=d.Department_ID
GROUP BY d.Name;

-- 5
SELECT COUNT(*)
FROM Employee e
JOIN Department d
ON e.Department_ID=d.Department_ID
WHERE d.Name='Sales';

-- 6
SELECT d.Name
FROM Employee e
JOIN Department d
ON e.Department_ID=d.Department_ID
GROUP BY d.Name
HAVING COUNT(*)>=5
ORDER BY d.Name;

-- 7
SELECT j.Designation,
COUNT(*)
FROM Employee e
JOIN Job j
ON e.Job_ID=j.Job_ID
GROUP BY j.Designation;

-- 8
SELECT COUNT(*)
FROM Employee e
JOIN Department d
ON e.Department_ID=d.Department_ID
JOIN Location l
ON d.Location_ID=l.Location_ID
WHERE l.City='New York';

-- 9
SELECT *,
CASE
WHEN Salary<1000 THEN 'A'
WHEN Salary BETWEEN 1000 AND 1999 THEN 'B'
WHEN Salary BETWEEN 2000 AND 2999 THEN 'C'
WHEN Salary BETWEEN 3000 AND 3999 THEN 'D'
ELSE 'E'
END AS Grade
FROM Employee;

-- 10
SELECT
CASE
WHEN Salary<1000 THEN 'A'
WHEN Salary BETWEEN 1000 AND 1999 THEN 'B'
WHEN Salary BETWEEN 2000 AND 2999 THEN 'C'
WHEN Salary BETWEEN 3000 AND 3999 THEN 'D'
ELSE 'E'
END AS Grade,
COUNT(*)
FROM Employee
GROUP BY Grade;

-- 11
SELECT
CASE
WHEN Salary BETWEEN 2000 AND 5000 THEN '2000-5000'
END AS Grade,
COUNT(*)
FROM Employee
WHERE Salary BETWEEN 2000 AND 5000
GROUP BY Grade;

-- 12
SELECT e.*
FROM Employee e
JOIN Department d
ON e.Department_ID=d.Department_ID
WHERE d.Name IN ('Sales','Operations');

--SET Operators

-- 1
SELECT DISTINCT Job_ID
FROM Employee
WHERE Department_ID=
(SELECT Department_ID FROM Department WHERE Name='Sales')

UNION

SELECT DISTINCT Job_ID
FROM Employee
WHERE Department_ID=
(SELECT Department_ID FROM Department WHERE Name='Accounting');

-- 2
SELECT Job_ID
FROM Employee
WHERE Department_ID=
(SELECT Department_ID FROM Department WHERE Name='Sales')

UNION ALL

SELECT Job_ID
FROM Employee
WHERE Department_ID=
(SELECT Department_ID FROM Department WHERE Name='Accounting');

-- 3
SELECT Job_ID
FROM Employee
WHERE Department_ID=
(SELECT Department_ID FROM Department WHERE Name='Research')

INTERSECT

SELECT Job_ID
FROM Employee
WHERE Department_ID=
(SELECT Department_ID FROM Department WHERE Name='Accounting')
ORDER BY Job_ID;

--Subqueries

-- 1
SELECT *
FROM Employee
WHERE Salary=(SELECT MAX(Salary) FROM Employee);

-- 2
SELECT *
FROM Employee
WHERE Department_ID=
(SELECT Department_ID
FROM Department
WHERE Name='Sales');

-- 3
SELECT *
FROM Employee
WHERE Job_ID=
(SELECT Job_ID
FROM Job
WHERE Designation='Clerk');

-- 4
SELECT *
FROM Employee
WHERE Department_ID IN
(
SELECT Department_ID
FROM Department
WHERE Location_ID=
(
SELECT Location_ID
FROM Location
WHERE City='New York'
)
);

-- 5
SELECT COUNT(*)
FROM Employee
WHERE Department_ID=
(
SELECT Department_ID
FROM Department
WHERE Name='Sales'
);

-- 6
UPDATE Employee
SET Salary=Salary*1.10
WHERE Job_ID=
(
SELECT Job_ID
FROM Job
WHERE Designation='Clerk'
);

-- 7
DELETE FROM Employee
WHERE Department_ID=
(
SELECT Department_ID
FROM Department
WHERE Name='Accounting'
);

-- 8
SELECT *
FROM Employee
WHERE Salary=
(
SELECT MAX(Salary)
FROM Employee
WHERE Salary<
(
SELECT MAX(Salary)
FROM Employee
)
);

-- 9 (Nth highest salary)
SELECT *
FROM Employee e1
WHERE (
    SELECT COUNT(DISTINCT e2.Salary)
    FROM Employee e2
    WHERE e2.Salary > e1.Salary
) = 2;

-- 10
SELECT *
FROM Employee
WHERE Salary>
ALL
(
SELECT Salary
FROM Employee
WHERE Department_ID=30
);

-- 11
SELECT *
FROM Employee
WHERE Salary>
(
SELECT MIN(Salary)
FROM Employee
WHERE Department_ID=30
);

-- 12
SELECT *
FROM Department
WHERE Department_ID NOT IN
(
SELECT DISTINCT Department_ID
FROM Employee
);

-- 13
SELECT *
FROM Employee e
WHERE Salary>
(
SELECT AVG(Salary)
FROM Employee
WHERE Department_ID=e.Department_ID
);