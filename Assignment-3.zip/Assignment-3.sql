select * from Jomato;
--1. Create a stored procedure to display the restaurant name, type and cuisine where the
--table booking is not zero.
CREATE PROCEDURE sp_GetTableBookingRestaurants
AS
BEGIN
    SELECT 
        RestaurantName,
        RestaurantType,
        CuisinesType
    FROM 
        Jomato
    WHERE 
        TableBooking IS NOT NULL AND TableBooking <> 0;
END;

--2. Create a transaction and update the cuisine type �Cafe� to �Cafeteria�. Check the result
--and rollback it.
BEGIN TRANSACTION;

UPDATE Jomato
SET CuisinesType = 'Cafeteria'
WHERE CuisinesType = 'Cafe';

SELECT RestaurantName, CuisinesType
FROM Jomato
WHERE CuisinesType = 'Cafeteria';


ROLLBACK;

--3. Generate a row number column and find the top 5 areas with the highest rating of
--restaurants.
WITH RankedAreas AS (
    SELECT 
        Area,
        Rating,
        ROW_NUMBER() OVER (ORDER BY Rating DESC) AS RowNum
    FROM 
        Jomato
)
SELECT TOP 5 *
FROM RankedAreas;

--4. Use the while loop to display the 1 to 50.
DECLARE @i INT = 1;

WHILE @i <= 50
BEGIN
    PRINT @i;
    SET @i = @i + 1;
END;

--5. Write a query to Create a Top rating view to store the generated top 5 highest rating of
--restaurants.
CREATE VIEW vw_Top5Ratings AS
SELECT TOP 5
    RestaurantName,
    Rating,
    RestaurantType,
    CuisinesType
FROM 
    Jomato
ORDER BY 
    Rating DESC;
   
 SELECT * FROM vw_Top5Ratings;

--6. Create a trigger that give an message whenever a new record is inserted.
CREATE TRIGGER trg_AfterInsert_Jomato
ON Jomato
AFTER INSERT
AS
BEGIN
    PRINT '? A new restaurant record has been inserted into the Jomato table.';
END;




