select * from Jomato;
--1. Create a user-defined functions to stuff the Chicken into �Quick Bites�. Eg: �Quick
--Chicken Bites�.

CREATE FUNCTION dbo.fn_StuffChicken
(
    @type NVARCHAR(100)
)
RETURNS NVARCHAR(200)
AS
BEGIN
    DECLARE @result NVARCHAR(200)
    
    IF @type = 'Quick Bites'
        SET @result = STUFF(@type, CHARINDEX('Bites', @type), 0, 'Chicken ')
    ELSE
        SET @result = @type

    RETURN @result
END;

--2. Use the function to display the restaurant name and cuisine type which has the
--maximum number of rating.
-- Get max number of ratings
DECLARE @maxRatings INT;

SELECT @maxRatings = MAX(No_of_Rating)
FROM Jomato;

-- Use the function and display
SELECT 
    RestaurantName,
    CuisinesType,
    dbo.fn_StuffChicken(RestaurantType) AS ModifiedRestaurantType,
    No_of_Rating
FROM 
    Jomato
WHERE 
    No_of_Rating = @maxRatings;

--3. Create a Rating Status column to display the rating as �Excellent� if it has more the 4
--start rating, �Good� if it has above 3.5 and below 4 star rating, �Average� if it is above 3
--and below 3.5 and �Bad� if it is below 3 star rating and
SELECT 
    RestaurantName,
    Rating,
    CASE 
        WHEN Rating > 4 THEN 'Excellent'
        WHEN Rating > 3.5 AND Rating <= 4 THEN 'Good'
        WHEN Rating > 3 AND Rating <= 3.5 THEN 'Average'
        WHEN Rating <= 3 THEN 'Bad'
    END AS RatingStatus
FROM 
    Jomato;

--4. Find the Ceil, floor and absolute values of the rating column and display the current
--date and separately display the year, month_name and day.
SELECT 
    RestaurantName,
    Rating,
    CEILING(Rating) AS CeilRating,
    FLOOR(Rating) AS FloorRating,
    ABS(Rating) AS AbsoluteRating,
    GETDATE() AS CurrentDate,
    YEAR(GETDATE()) AS Year,
    DATENAME(MONTH, GETDATE()) AS MonthName,
    DAY(GETDATE()) AS Day
FROM 
    Jomato;

--5. Display the restaurant type and total average cost using rollup.
SELECT 
    RestaurantType,
    SUM(AverageCost) AS TotalAverageCost
FROM 
    Jomato
GROUP BY 
    ROLLUP(RestaurantType);



