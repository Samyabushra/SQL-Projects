CREATE TABLE Salesman (
SalesmanId INT,
Name VARCHAR(255),
Commission DECIMAL(10, 2),
City VARCHAR(255),
Age INT
);
INSERT INTO Salesman (SalesmanId, Name, Commission, City, Age)
VALUES
(101, 'Joe', 50, 'California', 17),
(102, 'Simon', 75, 'Texas', 25),
(103, 'Jessie', 105, 'Florida', 35),
(104, 'Danny', 100, 'Texas', 22),
(105, 'Lia', 65, 'New Jersey', 30);
 

 CREATE TABLE Customer (
SalesmanId INT,
CustomerId INT,
CustomerName VARCHAR(255),
PurchaseAmount INT,
);

INSERT INTO Customer (SalesmanId, CustomerId, CustomerName, PurchaseAmount)
VALUES
(101, 2345, 'Andrew', 550),
(103, 1575, 'Lucky', 4500),
(104, 2345, 'Andrew', 4000),
(107, 3747, 'Remona', 2700),
(110, 4004, 'Julia', 4545);

CREATE TABLE Orders (OrderId int, CustomerId int, SalesmanId int, Orderdate Date, Amount
money)

INSERT INTO Orders Values
(5001,2345,101,'2021-07-01',550),
(5003,1234,105,'2022-02-15',1500)

--1. Insert a new record in your Orders table.
INSERT INTO Orders (OrderId, CustomerId, SalesmanId, OrderDate, Amount)
VALUES (5005, 1575, 103, '2025-07-18', 1200);



--2. Add Primary key constraint for SalesmanId column in Salesman table. Add default
--constraint for City column in Salesman table. Add Foreign key constraint for SalesmanId
--column in Customer table. Add not null constraint in Customer_name column for the
--Customer table.
-- Add Primary Key

ALTER TABLE Salesman
ALTER COLUMN SalesmanId INT NOT NULL;


ALTER TABLE Salesman
ADD CONSTRAINT PK_Salesman PRIMARY KEY (SalesmanId);

ALTER TABLE Salesman DROP CONSTRAINT DF_City;

ALTER TABLE Salesman
ADD CONSTRAINT DF_City DEFAULT 'Unknown' FOR City;

DELETE FROM Customer
WHERE SalesmanId NOT IN (SELECT SalesmanId FROM Salesman);


ALTER TABLE Customer ALTER COLUMN SalesmanId INT NOT NULL;
ALTER TABLE Salesman ALTER COLUMN SalesmanId INT NOT NULL;

ALTER TABLE Customer DROP CONSTRAINT IF EXISTS FK_Customer_Salesman;


ALTER TABLE Customer
ADD CONSTRAINT FK_Customer_Salesman FOREIGN KEY (SalesmanId)
REFERENCES Salesman(SalesmanId);




ALTER TABLE Customer
ALTER COLUMN CustomerName VARCHAR(100) NOT NULL;


--3. Fetch the data where the Customer�s name is ending with �N� also get the purchase
--amount value greater than 500.
SELECT * 
FROM Customer
WHERE CustomerName LIKE '%n'
  AND PurchaseAmount > 500;

--4. Using SET operators, retrieve the first result with unique SalesmanId values from two
--tables, and the other result containing SalesmanId with duplicates from two tables.
-- Unique SalesmanIds
SELECT SalesmanId FROM Customer
UNION
SELECT SalesmanId FROM Orders;

-- Duplicate SalesmanIds (appear in both tables)
SELECT SalesmanId FROM Customer
INTERSECT
SELECT SalesmanId FROM Orders;

--5. Display the below columns which has the matching data.
--Orderdate, Salesman Name, Customer Name, Commission, and City which has the
--range of Purchase Amount between 500 to 1500.
SELECT 
    O.OrderDate,
    S.Name,
    C.CustomerName,
    S.Commission,
    S.City
FROM Orders O
JOIN Salesman S ON O.SalesmanId = S.SalesmanId
JOIN Customer C ON O.CustomerId = C.CustomerId
WHERE C.PurchaseAmount BETWEEN 500 AND 1500;

--6. Using right join fetch all the results from Salesman and Orders table
SELECT 
    O.OrderId,
    O.CustomerId,
    O.SalesmanId,
    O.OrderDate,
    O.Amount,
    S.Name,
    S.Commission,
    S.City,
    S.Age
FROM Salesman S
RIGHT JOIN Orders O ON S.SalesmanId = O.SalesmanId;
