--1
SELECT COUNT(DISTINCT State) AS Total_States
FROM Location;

--2
SELECT COUNT(*) AS Total_Products
FROM Product1
WHERE Type='Regular';

--3
SELECT SUM(Marketing) AS Total_Marketing
FROM Fact
WHERE ProductID=1;

--4
SELECT MIN(Sales) AS Minimum_Sales
FROM Fact;

--5
SELECT MAX(COGS) AS Maximum_COGS
FROM Fact;

--6
SELECT *
FROM Product1
WHERE Product_Type='Coffee';

--7
SELECT *
FROM Fact
WHERE Total_Expenses>40;

--8

SELECT AVG(Sales) AS Average_Sales
FROM Fact
WHERE Area_Code=719;

--9

--10

SELECT ProductID,
AVG(Inventory) AS Average_Inventory
FROM Fact
GROUP BY ProductID;

--11
SELECT State
FROM Location
ORDER BY State;

--12
SELECT ProductID,
AVG(Budget_Margin) AS Avg_Budget_Margin
FROM Fact
GROUP BY ProductID
HAVING AVG(Budget_Margin)>100;

--13

SELECT SUM(Sales) AS Total_Sales
FROM Fact
WHERE Date='2010-01-01';

--14
SELECT Date,
ProductID,
AVG(Total_Expenses) AS Avg_Total_Expenses
FROM Fact
GROUP BY Date,ProductID;

--15
SELECT
f.Date,
f.ProductID,
p.Product_Type,
p.Product1,
f.Sales,
f.Profit,
l.State,
f.Area_Code
FROM Fact f
JOIN Product1 p
ON f.ProductID=p.ProductID
JOIN Location l
ON f.Area_Code=l.Area_Code;

--16
SELECT *,
DENSE_RANK() OVER(ORDER BY Sales DESC) AS Sales_Rank
FROM Fact;

--17
SELECT
l.State,
SUM(f.Profit) AS Profit,
SUM(f.Sales) AS Sales
FROM Fact f
JOIN Location l
ON f.Area_Code=l.Area_Code
GROUP BY l.State;

--18
SELECT
l.State,
p.Product1,
SUM(f.Profit) AS Profit,
SUM(f.Sales) AS Sales
FROM Fact f
JOIN Product1 p
ON f.ProductID=p.ProductID
JOIN Location l
ON f.Area_Code=l.Area_Code
GROUP BY l.State,p.Product1;

--19
SELECT
ProductID,
Sales,
Sales*1.05 AS Increased_Sales
FROM Fact;

--20
SELECT
f.ProductID,
p.Product_Type,
f.Profit
FROM Fact f
JOIN Product p
ON f.ProductID=p.ProductID
WHERE f.Profit=
(
SELECT MAX(Profit)
FROM Fact
);

--21
SELECT *,
CASE
WHEN Total_Expenses<60 THEN 'Profit'
ELSE 'Loss'
END AS Status
FROM Fact;

--22
SELECT
YEAR(Date),
WEEK(Date),
ProductID,
SUM(Sales)
FROM Fact
GROUP BY YEAR(Date),WEEK(Date),ProductID WITH ROLLUP;

--23
SELECT
YEAR(Date),
WEEK(Date),
ProductID,
SUM(Sales)
FROM Fact
GROUP BY YEAR(Date),WEEK(Date),ProductID WITH ROLLUP;

--24
-- UNION
SELECT Area_Code FROM Fact
UNION
SELECT Area_Code FROM Location;

-- INTERSECT
SELECT Area_Code FROM Fact
INTERSECT
SELECT Area_Code FROM Location;

--25
CREATE FUNCTION GetProduct(p_id INT)
RETURNS VARCHAR(50)
DETERMINISTIC
RETURN
(
SELECT Product_Type
FROM Product1
WHERE ProductID=p_id
);

--26
UPDATE Product1
SET Product_Type='Tea'
WHERE ProductID=1;

ROLLBACK;

--27
SELECT Date,
ProductID,
Sales
FROM Fact
WHERE Total_Expenses BETWEEN 100 AND 200;

--28
DELETE FROM Product1
WHERE Type='Regular';

--29
SELECT Product1,
ASCII(SUBSTRING(Product1,5,1)) AS ASCII_Value
FROM Product1;

--30
